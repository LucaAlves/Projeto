/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula1;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Aula1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame janela = new JFrame("Projeto Disciplina!");
        JPanel painel = new JPanel();
        janela.setSize(300,200);
        janela.setVisible(true);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.add(painel);
        JLabel rotulo = new JLabel();
        String number = JOptionPane.showInputDialog ("Digite um Número:");
        JOptionPane.showMessageDialog(null,"O número digitado foi " + number,"IFRO",JOptionPane.PLAIN_MESSAGE);
       // Icon icone = new ImageIcon(getResource("/imagens/01.png"));
        rotulo.setText("Nome");
        painel.add(rotulo);
        
    }
    
    
}
